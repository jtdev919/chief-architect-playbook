# Event Flow — Order Lifecycle  
This sequence diagram shows how events flow across services in an event-driven architecture.

```mermaid
sequenceDiagram
    participant API as API Gateway
    participant OS as Order Service
    participant EB as Event Bus
    participant IS as Inventory Service

    API->>OS: POST /orders
    OS->>OS: Validate & process order
    OS->>EB: Publish OrderCreated event
    EB->>IS: Deliver OrderCreated event
    IS->>IS: Reserve inventory
    IS->>EB: Publish InventoryReserved event