# C4 Diagram — Level 2: Container View  
This diagram shows the major containers (APIs, services, platforms) that make up the enterprise system.

```mermaid
C4Container
    title North Star Architecture — Container View (L2)

    Person(customer, "Customer")
    Person(engineer, "Engineering Team")

    System_Boundary(platform, "Enterprise Platform") {

        Container(apiGateway, "API Gateway", "Kong / Apigee / MuleSoft", "Routing, auth, rate limiting")
        Container(authService, "Identity & Access Service", "Auth0 / Cognito", "Authentication, authorization")
        Container(eventBus, "Event Bus", "Kafka / EventBridge", "Pub/sub, streaming")
        Container(dataLake, "Data Lakehouse", "Delta Lake / Snowflake", "Raw + curated data")
        Container(analytics, "Analytics Engine", "Databricks / BigQuery", "ML, BI, dashboards")
        Container(ciCd, "CI/CD Platform", "GitHub Actions / ArgoCD", "Build, test, deploy automation")

        Container_Boundary(domain, "Domain Services") {
            Container(orderSvc, "Order Service", "Microservice", "Order lifecycle")
            Container(customerSvc, "Customer Service", "Microservice", "Customer profiles")
            Container(inventorySvc, "Inventory Service", "Microservice", "Stock levels")
        }
    }

    Rel(customer, apiGateway, "Uses")
    Rel(apiGateway, authService, "Validates identity")
    Rel(apiGateway, orderSvc, "Routes API calls")
    Rel(orderSvc, eventBus, "Publishes events")
    Rel(eventBus, inventorySvc, "Consumes events")
    Rel(orderSvc, dataLake, "Sends operational data")
    Rel(analytics, dataLake, "Reads data")
    Rel(engineer, ciCd, "Builds & deploys services")